# Aspataal: Production Hosting & Deployment Guide

Congratulations! The Aspataal platform is now a **100% Fully Functional Full-Stack Application**. The frontend is seamlessly integrated with the custom backend API, and all data is securely managed by the SQLite relational database.

Because the project is fully built, it is ready to be hosted live on the web today.

## Deployment Strategy

Since this project utilizes a local SQLite database file (`aspataal.db`) to store records and user feedback, it must be hosted on a platform that supports **Persistent Storage** (a persistent file system). 

> [!WARNING]
> Do **not** deploy this specific version to serverless platforms like **Vercel** or **Netlify**. Those platforms use ephemeral file systems, meaning your SQLite database will be completely erased every time the server restarts or goes to sleep.

### Recommended Host: Render.com (Free & Easy)

[Render.com](https://render.com) is the best platform for hosting Node.js applications with persistent SQLite databases for free/cheap.

#### Step 1: Push to GitHub
1. Create a repository on GitHub.
2. Push your local `top-hospitals` folder to that GitHub repository.

#### Step 2: Create a Web Service on Render
1. Go to Render.com and create an account.
2. Click **New +** and select **Web Service**.
3. Connect your GitHub account and select your Aspataal repository.

#### Step 3: Configure the Build Settings
Fill out the configuration fields exactly like this:
* **Environment:** `Node`
* **Build Command:** `npm install && npm run build`
* **Start Command:** `npm run start`

#### Step 4: Add a Persistent Disk (CRITICAL)
For your SQLite database to survive server restarts, you must add a Disk.
1. Scroll down to **Advanced**.
2. Click **Add Disk**.
3. **Name:** `sqlite-data`
4. **Mount Path:** `/opt/render/project/src`
5. **Size:** `1 GB` (Plenty for SQLite)

#### Step 5: Deploy
Click **Create Web Service**. Render will automatically build your Next.js application, start the server, and provide you with a live, public `.onrender.com` URL!

---

## Alternative: Hosting on a VPS (DigitalOcean / AWS / Linux)

If you are deploying this for a college project and want to use a raw Linux Virtual Machine (like an AWS EC2 instance or DigitalOcean Droplet), follow these commands on your server terminal:

```bash
# 1. Clone your code
git clone <your-repo-url>
cd top-hospitals

# 2. Install dependencies
npm install

# 3. Create the Production Build
npm run build

# 4. Start the Production Server
npm run start
```
Your website will now be live on your server's public IP address at port 3000 (e.g., `http://192.168.1.100:3000`). You can then use Nginx or Apache as a reverse proxy to map it to a real domain name like `www.aspataal.com`.
