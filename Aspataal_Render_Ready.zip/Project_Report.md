# HOSPITAL MANAGEMENT SYSTEM WITH HL7 INTEGRATION

## 1. SYSTEM OVERVIEW

### What is a Hospital Management System (HMS)?
Imagine a hospital as a giant, incredibly busy machine. Doctors, nurses, patients, medicines, and money are moving around all the time. A **Hospital Management System (HMS)** is the software "brain" that manages everything. Instead of using messy paper files that can get lost, an HMS keeps track of patient records, doctor schedules, room availability, and billing in one central digital place.

### Why is HL7 Important in Hospitals?
Different hospitals, laboratories, and pharmacies often use completely different software. If Software A (the hospital) tries to send a patient's blood test request to Software B (an external lab), they might not understand each other—like two people speaking different languages. 

**HL7 (Health Level Seven)** is the "universal translator" for healthcare software. It sets standard formatting rules so any medical software can seamlessly talk to any other medical software, regardless of who built it. 

### Real-World Hospital Workflow
1. A patient walks into the hospital and registers at the front desk.
2. The HMS stores their details and instantly sends an automated HL7 message to other departments (like the lab or ward) saying, "A new patient has arrived."
3. The doctor writes a prescription in the system. The system sends an HL7 message to the pharmacy to prepare the medicine.
4. All departments stay in sync instantly without printing a single piece of paper.

---

## 2. MODULES

A modern HMS is divided into different building blocks called "modules".

* **Patient Registration:** Handles new patient onboarding, generating a unique Patient ID (MRN - Medical Record Number), and capturing demographics (name, age, contact).
* **Doctor Management:** Manages doctor profiles, their specialties, shift timings, and department assignments.
* **Appointment Scheduling:** Allows receptionists or patients to book, cancel, or reschedule visits with specific doctors.
* **Electronic Medical Records (EMR):** The digital version of a patient's medical history, including past diagnoses, allergies, and doctors' notes.
* **Lab & Test Reports:** Manages the ordering of tests (blood, X-ray) and the delivery of results back to the doctor.
* **Billing & Insurance:** Calculates the final bill (consultation + lab + pharmacy), applies insurance coverage, and processes payments.
* **Pharmacy Management:** Tracks medicine inventory, expiration dates, and processes prescriptions.
* **HL7 Integration Module:** A background service that watches the system. When an event happens (like a patient registering), it formats that data into HL7 and sends it to other systems.

---

## 3. HL7 INTEGRATION (CORE COMPONENT)

### HL7 in Simple Words
Think of HL7 like a standardized text message. If you want to send someone a contact card on your phone, there is a standard format (vCard) so an iPhone can send it to an Android without breaking. HL7 is exactly that, but for patient data.

### Important HL7 Message Types
HL7 messages are categorized by "Trigger Events"—things that happen in the real world.
1. **ADT (Admit, Discharge, Transfer):** Used when a patient's location or status changes. (e.g., ADT^A01 means "Patient Admitted").
2. **ORM (Order Message):** Used when a doctor orders a service, like requesting a blood test or an X-Ray.
3. **ORU (Observation Result):** Used when the lab sends the completed test results back to the doctor's system.

### Sample HL7 Message (ADT^A01 - Patient Admission)
HL7 messages look like a block of text separated by `|` (pipes).
```hl7
MSH|^~\&|HMS_SENDER|CITY_HOSPITAL|LAB_RECEIVER|LAB|202310251430||ADT^A01|MSG12345|P|2.4
PID|1||MRN9999^^^HOSPITAL||Doe^John||19800101|M|||123 Main St^^New York^NY^10001||555-1234
PV1|1|I|WARD_A^101^1||||DOC001^Smith^James
```
* **MSH (Message Header):** Shows who sent it, who receives it, and the time.
* **PID (Patient Identification):** Contains patient name (John Doe), DOB, Gender, and Address.
* **PV1 (Patient Visit):** Contains the location (Ward A, Room 101) and the attending doctor (Dr. James Smith).

### How Hospitals Send/Receive HL7 Data
Data flows using TCP/IP (over a network). The HMS acts as a sender, taking database information, translating it into HL7, and pushing it to a receiving port on a different software.

---

## 4. SYSTEM ARCHITECTURE

The project follows a standard 3-tier Microservices Architecture connected to an HL7 Interface Engine.

```text
[ User Interface (React.js) ]  <-- (JSON over REST API) -->  [ Backend Server (Spring Boot) ]
                                                                     |
                                                               (Read/Write)
                                                                     |
                                                           [ Database (PostgreSQL) ]
                                                                     |
                                                          (Event Triggers HL7 Message)
                                                                     |
                                                                     v
                                                   [ HL7 Interface Engine (Mirth Connect) ]
                                                              /              \
                                                    (TCP/IP HL7)          (TCP/IP HL7)
                                                           /                    \
                                                  [ External Lab ]         [ Pharmacy System ]
```

* **Frontend:** What the user sees and interacts with.
* **Backend:** Contains the business logic and API endpoints.
* **Database:** Where all raw data is stored securely.
* **HL7 Interface Engine:** A specialized router (like Mirth Connect) that takes outgoing HL7 messages from our backend and safely delivers them to external systems.

---

## 5. TECHNOLOGY STACK

* **Frontend:** React.js (Component-based UI), Tailwind CSS (Styling)
* **Backend:** Java Spring Boot (Robust, scalable, excellent HL7 libraries)
* **Database:** PostgreSQL (Relational database with strong data integrity)
* **HL7 Tools:** 
  * *HAPI HL7 (Java Library)* - Used in the backend to programmatically build and read HL7 text.
  * *Mirth Connect (NextGen Connect)* - An open-source interface engine to route the messages.
* **Security:** JWT (JSON Web Tokens) for API Authentication, bcrypt for password hashing.

---

## 6. DATABASE DESIGN (ER DIAGRAM EXPLANATION)

### Core Tables & Relationships
1. **Patient Table**
   * Primary Key: `patient_id`
   * Fields: `first_name`, `last_name`, `dob`, `gender`, `contact_number`
2. **Doctor Table**
   * Primary Key: `doctor_id`
   * Fields: `name`, `specialty`, `phone`
3. **Appointment Table**
   * Primary Key: `appointment_id`
   * Foreign Keys: `patient_id`, `doctor_id`
   * Fields: `appointment_date`, `status`
4. **MedicalRecords Table**
   * Primary Key: `record_id`
   * Foreign Keys: `patient_id`, `doctor_id`
   * Fields: `diagnosis`, `prescription`, `date_created`
5. **HL7_Message_Logs Table** (For auditing)
   * Primary Key: `log_id`
   * Fields: `message_type` (e.g., ADT), `raw_message`, `status` (Sent/Failed), `timestamp`

*Relationship logic:* A Patient can have multiple Appointments (1-to-Many). An Appointment links exactly one Patient to exactly one Doctor.

---

## 7. WORKING FLOW (Step-by-Step)

1. **Registration:** A receptionist inputs John Doe's details into the React Frontend.
2. **Data Save:** React sends a JSON API request to the Spring Boot Backend. The backend saves John to PostgreSQL.
3. **HL7 Trigger:** The backend detects a new patient. It uses the HAPI HL7 library to create an `ADT^A01` message.
4. **Routing:** The backend sends this `ADT^A01` message over TCP/IP to Mirth Connect.
5. **Delivery:** Mirth Connect forwards this to the hospital's independent Laboratory Information System.
6. **Consultation:** John sees the doctor. The doctor uses the HMS to order a blood test (Triggers `ORM^O01` to the Lab).
7. **Results:** The lab completes the test and sends an `ORU^R01` message back. The backend parses it and attaches the PDF/results to John's EMR.

---

## 8. SAMPLE CODE

### 8.1 Backend API: Patient Registration (Spring Boot)
```java
@RestController
@RequestMapping("/api/patients")
public class PatientController {

    @Autowired
    private PatientRepository patientRepo;

    @Autowired
    private Hl7IntegrationService hl7Service;

    @PostMapping("/register")
    public ResponseEntity<String> registerPatient(@RequestBody Patient patient) {
        // 1. Save patient to Database
        Patient savedPatient = patientRepo.save(patient);
        
        // 2. Generate and Send HL7 ADT Message asynchronously 
        hl7Service.sendAdtRegistrationMessage(savedPatient);
        
        return ResponseEntity.ok("Patient Registered Successfully. HL7 ADT Broadcasted.");
    }
}
```

### 8.2 Building an HL7 Message using HAPI (Java)
```java
import ca.uhn.hl7v2.model.v24.message.ADT_A01;
import ca.uhn.hl7v2.model.v24.segment.PID;
import ca.uhn.hl7v2.model.v24.segment.MSH;

public String createADTMessage(Patient patient) throws Exception {
    ADT_A01 adt = new ADT_A01();
    adt.initQuickstart("ADT", "A01", "P"); // Message Type, Trigger Event, Processing ID

    // Populate Header (MSH)
    MSH msh = adt.getMSH();
    msh.getSendingApplication().getNamespaceID().setValue("HMS_CORE");
    
    // Populate Patient Data (PID)
    PID pid = adt.getPID();
    pid.getPatientID().getID().setValue(patient.getId().toString());
    pid.getPatientName(0).getFamilyName().getSurname().setValue(patient.getLastName());
    pid.getPatientName(0).getGivenName().setValue(patient.getFirstName());
    
    // Convert Java Object to HL7 String
    HapiContext context = new DefaultHapiContext();
    String encodedMessage = context.getPipeParser().encode(adt);
    context.close();
    
    return encodedMessage;
}
```

### 8.3 Parsing an Incoming HL7 Message
```java
public void receiveTestResults(String incomingHl7Str) throws Exception {
    HapiContext context = new DefaultHapiContext();
    Parser parser = context.getPipeParser();
    
    // Parse the string into a generic message
    Message hapiMsg = parser.parse(incomingHl7Str);
    
    if (hapiMsg instanceof ORU_R01) {
        ORU_R01 oruMsg = (ORU_R01) hapiMsg;
        String patientName = oruMsg.getPATIENT_RESULT().getPATIENT().getPID()
                                   .getPatientName(0).getGivenName().getValue();
        System.out.println("Received Test Results for: " + patientName);
        // Logic to update database with results goes here
    }
}
```

---

## 9. FEATURES

* **Role-Based Access Control (RBAC):** 
  * *Admin:* Full system access.
  * *Doctor:* Can view EMRs, write prescriptions, and order labs.
  * *Receptionist:* Can only register patients and book appointments.
* **High Security:** Data is encrypted at rest (PostgreSQL) and in transit (HTTPS/TLS).
* **True Interoperability:** By supporting HL7, the hospital is not locked into one vendor. They can buy an MRI machine from GE and a Lab system from Siemens, and the HMS will talk to both.
* **Audit Trails:** Every HL7 message sent or received is logged for legal compliance (HIPAA).

---

## 10. ADVANTAGES & LIMITATIONS

### Advantages
* **Eliminates Manual Data Entry:** When a patient is registered, the data flows everywhere automatically. Zero double-typing.
* **Reduces Medical Errors:** Since doctors receive lab results directly into the HMS rather than reading a printed fax, the chance of misreading data is heavily reduced.
* **Real-time Processing:** Faster patient care because data moves at the speed of light.

### Limitations
* **Implementation Complexity:** Setting up HL7 connections requires deep networking and domain knowledge.
* **Strict Formatting:** Even a single missing pipe `|` character in an HL7 message can cause the receiving system to crash or reject the data.

### Future Scope
* **Transition to FHIR:** While HL7 v2 is standard, the future is **FHIR (Fast Healthcare Interoperability Resources)**, which uses modern REST APIs and JSON instead of pipe-delimited text.
* **AI Integration:** Using machine learning to read EMR data and predict patient readmission risks.

---

## 11. TESTING

For an academic submission, testing ensures the system's reliability.
1. **Unit Testing:** Using JUnit in Spring Boot to ensure `PatientController` saves users correctly.
2. **Integration Testing:** Creating a test patient and verifying that an appointment can be booked under that Patient ID.
3. **HL7 Message Validation Testing:** Using the HAPI library's built-in validation tools to test if our generated `ADT^A01` messages conform perfectly to the official HL7 v2.4 specification before we send them out.

---

## 12. CONCLUSION

This project demonstrates the end-to-end development of a modern, interoperable Hospital Management System. By combining contemporary web technologies (React, Spring Boot, PostgreSQL) with industry-standard healthcare protocols (HL7 and Mirth Connect), this system bridges the gap between software engineering and healthcare IT. 

The successful integration of HL7 proves that the system is ready for real-world deployment, capable of talking to disparate external medical systems. It provides an excellent learning outcome in understanding microservices, health informatics, and data standardization.
