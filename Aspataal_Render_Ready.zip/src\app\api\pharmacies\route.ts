import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET() {
  try {
    const db = await getDb();
    const pharmacies = await db.all('SELECT * FROM pharmacies');
    
    // Parse boolean fields
    const parsed = pharmacies.map(p => ({
      ...p,
      isOpen24x7: p.isOpen24x7 === 1
    }));
    
    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch pharmacies' }, { status: 500 });
  }
}
