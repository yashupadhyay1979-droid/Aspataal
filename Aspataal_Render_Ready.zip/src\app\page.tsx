"use client";

import { useEffect, useState } from "react";

interface Doctor {
  id: number;
  name: string;
  hospitalId: number;
  specialty: string;
  qualifications: string;
  experience: string;
  image: string;
}

interface Hospital {
  id: number;
  name: string;
  location: string;
  primarySpecialty: string;
  specialties: string[];
  rating: number;
  image: string;
  contact: string;
  mapLink: string;
}

interface Pharmacy {
  id: number;
  name: string;
  location: string;
  rating: number;
  isOpen24x7: boolean;
  contact: string;
  image: string;
  mapLink: string;
}

interface Clinic {
  id: number;
  name: string;
  doctorName: string;
  specialty: string;
  location: string;
  rating: number;
  contact: string;
  image: string;
  mapLink: string;
}

interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  bloodGroup: string;
  contact: string;
  history: string[];
  reports: { date: string; testName: string; result: string }[];
  doctors: { id: number; name: string; specialty: string }[];
  billing: { invoiceId: string; date: string; amount: string; status: string }[];
}

const SPECIALTIES = ["All", "Cardiology", "Neurology", "Orthopedics", "Oncology", "Pediatrics", "Gastroenterology", "Gynecology", "Urology", "Dermatology", "Ophthalmology"];

export default function Home() {
  const [activeTab, setActiveTab] = useState<'hospitals' | 'pharmacies' | 'clinics' | 'patients'>('hospitals');
  const [activeSpecialty, setActiveSpecialty] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [clinics, setClinics] = useState<Clinic[]>([]);
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  
  const [expandedHospital, setExpandedHospital] = useState<number | null>(null);
  const [expandedPatient, setExpandedPatient] = useState<string | null>(null);

  // Feedback Form State
  const [feedbackName, setFeedbackName] = useState("");
  const [feedbackEmail, setFeedbackEmail] = useState("");
  const [feedbackRating, setFeedbackRating] = useState("");
  const [feedbackMessage, setFeedbackMessage] = useState("");
  const [feedbackStatus, setFeedbackStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');

  useEffect(() => {
    Promise.all([
      fetch("/api/hospitals").then(res => res.json()),
      fetch("/api/pharmacies").then(res => res.json()),
      fetch("/api/clinics").then(res => res.json()),
      fetch("/api/doctors").then(res => res.json()),
      fetch("/api/patients").then(res => res.json())
    ]).then(([hData, pData, cData, dData, ptData]) => {
      setHospitals(hData);
      setPharmacies(pData);
      setClinics(cData);
      setDoctors(dData);
      setPatients(ptData);
      setLoading(false);
    });
  }, []);

  const filteredHospitals = hospitals.filter(h => {
    const matchesSearch = h.name.toLowerCase().includes(searchTerm.toLowerCase()) || h.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSpecialty = activeSpecialty === "All" || h.specialties.includes(activeSpecialty);
    return matchesSearch && matchesSpecialty;
  });

  const filteredPharmacies = pharmacies.filter(p => p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.location.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredClinics = clinics.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.location.toLowerCase().includes(searchTerm.toLowerCase()) || c.specialty.includes(activeSpecialty === "All" ? "" : activeSpecialty));
  const filteredPatients = patients.filter(pt => pt.name.toLowerCase().includes(searchTerm.toLowerCase()) || pt.id.toLowerCase().includes(searchTerm.toLowerCase()));

  const toggleHospital = (id: number) => {
    setExpandedHospital(expandedHospital === id ? null : id);
  };
  
  const togglePatient = (id: string) => {
    setExpandedPatient(expandedPatient === id ? null : id);
  };

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedbackStatus('submitting');
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: feedbackName,
          email: feedbackEmail,
          rating: feedbackRating || '🙂',
          message: feedbackMessage
        })
      });
      if (res.ok) {
        setFeedbackStatus('success');
        setFeedbackName(""); setFeedbackEmail(""); setFeedbackMessage(""); setFeedbackRating("");
        setTimeout(() => setFeedbackStatus('idle'), 5000);
      } else {
        setFeedbackStatus('error');
        setTimeout(() => setFeedbackStatus('idle'), 5000);
      }
    } catch (err) {
      setFeedbackStatus('error');
      setTimeout(() => setFeedbackStatus('idle'), 5000);
    }
  };

  return (
    <main className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-teal-200">
      
      {/* Top Header */}
      <header className="absolute top-0 left-0 w-full p-4 md:p-6 z-50 flex justify-between items-center">
        <div 
          className="text-2xl font-extrabold text-white tracking-wider flex items-center gap-2 cursor-pointer" 
          onClick={() => { setActiveTab('hospitals'); }}
        >
           <span className="text-teal-300">✚</span> Aspataal
        </div>
        <div className="flex items-center gap-4">
          <div className="relative hidden md:block">
            <select className="bg-white/10 text-white border border-white/30 rounded-full pl-4 pr-10 py-2.5 text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-400 appearance-none cursor-pointer backdrop-blur-md hover:bg-white/20 transition-colors">
              <option className="text-slate-800">🌐 English</option>
              <option className="text-slate-800">🌐 Hindi</option>
              <option className="text-slate-800">🌐 Kannada</option>
              <option className="text-slate-800">🌐 Tamil</option>
            </select>
            <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3 text-white">
              <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
            </div>
          </div>

          <button 
            onClick={() => { setActiveTab('patients'); setExpandedPatient(null); }}
            className="bg-white/20 hover:bg-white/30 backdrop-blur-md text-white px-5 py-2.5 rounded-full font-semibold transition-colors shadow-sm flex items-center gap-2 border border-white/30"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
            <span className="hidden md:inline">Patient Portal</span>
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <div className="bg-gradient-to-br from-teal-700 via-emerald-800 to-green-900 pt-32 pb-24 px-6 text-center text-white shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 pointer-events-none">
          <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full bg-white blur-3xl"></div>
          <div className="absolute bottom-0 right-0 w-full h-64 bg-gradient-to-t from-black/20 to-transparent"></div>
        </div>
        
        <div className="relative z-10 max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight leading-tight">
            Welcome to <span className="text-teal-300">Aspataal</span>
          </h1>
          <p className="text-xl md:text-2xl font-light max-w-2xl mx-auto text-teal-100 opacity-90 leading-relaxed">
            Your comprehensive healthcare companion. Discover top hospitals, medical shops, personal clinics, and secure patient records.
          </p>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="max-w-4xl mx-auto -mt-6 relative z-30 px-4">
        <div className="flex bg-white rounded-2xl shadow-xl p-2 border border-slate-100 mx-auto justify-between overflow-x-auto hide-scrollbar">
          {(['hospitals', 'pharmacies', 'clinics'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => { setActiveTab(tab); setExpandedHospital(null); setExpandedPatient(null); }}
              className={`flex-1 py-3 px-6 rounded-xl font-semibold text-lg transition-all duration-300 capitalize whitespace-nowrap ${activeTab === tab ? 'bg-teal-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* Search & Filters */}
      <div className="max-w-7xl mx-auto mt-12 px-6">
        <div className="flex flex-col md:flex-row gap-6 items-center justify-between mb-10">
          <div className="relative w-full md:w-1/2">
            <svg className="w-6 h-6 text-slate-400 absolute left-4 top-1/2 transform -translate-y-1/2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
            <input
              type="text"
              placeholder={`Search ${activeTab === 'patients' ? 'records' : activeTab}...`}
              className="w-full bg-white border border-slate-200 rounded-2xl py-4 pl-12 pr-4 text-lg focus:outline-none focus:ring-4 focus:ring-teal-500/20 transition-all shadow-sm"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {(activeTab === 'hospitals' || activeTab === 'clinics') && (
            <div className="w-full md:w-1/2 overflow-x-auto hide-scrollbar pb-2">
              <div className="flex gap-2">
                {SPECIALTIES.map(spec => (
                  <button
                    key={spec}
                    onClick={() => setActiveSpecialty(spec)}
                    className={`px-4 py-2 rounded-full whitespace-nowrap text-sm font-medium transition-colors border ${activeSpecialty === spec ? 'bg-teal-600 text-white border-teal-600' : 'bg-white text-slate-600 border-slate-200 hover:border-teal-300'}`}
                  >
                    {spec}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Content Area */}
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-teal-600"></div>
          </div>
        ) : (
          <div>
            {/* HOSPITALS TAB */}
            {activeTab === 'hospitals' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
                {filteredHospitals.slice(0, 50).map((hospital) => (
                  <div key={hospital.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-xl transition-all border border-slate-100 flex flex-col">
                    <div className="relative h-48 w-full bg-slate-200">
                      <img src={hospital.image} alt={hospital.name} className="w-full h-full object-cover" />
                      <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-md px-3 py-1 rounded-full text-sm font-bold text-teal-700 shadow flex items-center gap-1">
                        <span className="text-yellow-400">★</span> {hospital.rating}
                      </div>
                    </div>
                    <div className="p-5 flex flex-col flex-1">
                      <h3 className="text-xl font-bold mb-2 text-slate-800 line-clamp-1">{hospital.name}</h3>
                      <p className="text-slate-500 text-sm mb-4 flex items-center gap-1">
                        <svg className="w-4 h-4 text-teal-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" /></svg>
                        {hospital.location}
                        <a href={hospital.mapLink} target="_blank" rel="noopener noreferrer" className="ml-auto text-xs text-blue-500 hover:text-blue-700 font-bold flex items-center gap-1">
                           Map ↗
                        </a>
                      </p>
                      
                      <div className="flex flex-wrap gap-1 mb-4">
                        {hospital.specialties.slice(0, 2).map((spec, idx) => (
                          <span key={idx} className="px-2 py-1 bg-teal-50 text-teal-700 rounded-lg text-xs font-semibold">{spec}</span>
                        ))}
                      </div>

                      <div className="mt-auto pt-4 border-t border-slate-100">
                        <button 
                          onClick={() => toggleHospital(hospital.id)}
                          className="w-full py-2 bg-slate-50 hover:bg-teal-50 text-teal-700 rounded-xl text-sm font-bold transition-colors flex justify-center items-center gap-2"
                        >
                          {expandedHospital === hospital.id ? "Hide Doctors" : "View Specialists"}
                        </button>
                      </div>
                    </div>

                    {/* Expandable Doctors List */}
                    {expandedHospital === hospital.id && (
                      <div className="bg-slate-50 p-4 border-t border-slate-200 animate-in slide-in-from-top-4 fade-in duration-300">
                        <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-3">Available Specialists</h4>
                        <div className="flex flex-col gap-3">
                          {doctors.filter(d => d.hospitalId === hospital.id).map(doc => (
                            <div key={doc.id} className="flex gap-3 items-center bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                              <img src={doc.image} alt={doc.name} className="w-10 h-10 rounded-full" />
                              <div>
                                <p className="font-bold text-slate-800 text-sm">{doc.name}</p>
                                <p className="text-teal-600 text-xs font-semibold">{doc.specialty} • {doc.qualifications}</p>
                                <p className="text-slate-400 text-xs">{doc.experience} exp.</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* PHARMACIES TAB */}
            {activeTab === 'pharmacies' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredPharmacies.slice(0, 50).map((pharmacy) => (
                  <div key={pharmacy.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-start gap-4 hover:shadow-md transition-shadow">
                    <div className="w-16 h-16 bg-teal-100 rounded-2xl overflow-hidden shrink-0 shadow-inner">
                      <img src={pharmacy.image} alt={pharmacy.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-slate-800 leading-tight mb-1">{pharmacy.name}</h3>
                      <div className="text-sm text-slate-500 flex items-center justify-between">
                        <span>{pharmacy.location}</span>
                        <a href={pharmacy.mapLink} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:text-blue-700 font-bold">Map ↗</a>
                      </div>
                      <div className="flex items-center gap-3 mt-3">
                        <span className="text-xs font-bold bg-slate-100 px-2 py-1 rounded-lg text-slate-600">★ {pharmacy.rating}</span>
                        {pharmacy.isOpen24x7 && <span className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded-lg">24x7 Open</span>}
                      </div>
                      <p className="text-sm font-semibold text-slate-600 mt-3">{pharmacy.contact}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* CLINICS TAB */}
            {activeTab === 'clinics' && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredClinics.slice(0, 50).map((clinic) => (
                  <div key={clinic.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex items-start gap-4 hover:shadow-md transition-shadow relative overflow-hidden">
                    <div className="absolute right-0 top-0 w-24 h-24 bg-teal-50 rounded-bl-full -z-10"></div>
                    <div className="w-16 h-16 bg-teal-600 rounded-full overflow-hidden shrink-0 shadow-inner border-2 border-white">
                      <img src={clinic.image} alt={clinic.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-slate-800 leading-tight mb-1">{clinic.name}</h3>
                      <p className="text-sm font-bold text-teal-600 mb-2">{clinic.doctorName}</p>
                      <p className="text-xs text-slate-500 bg-slate-100 inline-block px-2 py-1 rounded-lg mb-3">{clinic.specialty}</p>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-slate-500">{clinic.location}</p>
                        <a href={clinic.mapLink} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:text-blue-700 font-bold">Map ↗</a>
                      </div>
                      <p className="text-sm font-semibold text-slate-600 mt-2">{clinic.contact}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* PATIENTS TAB */}
            {activeTab === 'patients' && (
              <div className="grid grid-cols-1 gap-6 max-w-5xl mx-auto">
                {filteredPatients.slice(0, 20).map((patient) => (
                  <div key={patient.id} className="bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition-all border border-slate-200">
                    {/* Patient Header */}
                    <div 
                      className="p-6 cursor-pointer flex items-center justify-between hover:bg-slate-50"
                      onClick={() => togglePatient(patient.id)}
                    >
                      <div className="flex items-center gap-6">
                        <div className="w-16 h-16 rounded-2xl bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-2xl border border-indigo-200">
                          {patient.name.charAt(0)}
                        </div>
                        <div>
                          <h3 className="text-2xl font-bold text-slate-800">{patient.name}</h3>
                          <div className="flex gap-4 text-sm text-slate-500 mt-1 font-medium">
                            <span className="bg-slate-100 px-2 py-1 rounded-md">MRN: <span className="font-bold text-slate-700">{patient.id}</span></span>
                            <span>{patient.age} yrs • {patient.gender} • {patient.bloodGroup}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-indigo-500">
                        <svg className={`w-8 h-8 transition-transform duration-300 ${expandedPatient === patient.id ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" /></svg>
                      </div>
                    </div>

                    {/* Expandable EMR Content */}
                    {expandedPatient === patient.id && (
                      <div className="bg-slate-50 border-t border-slate-200 p-8 grid grid-cols-1 md:grid-cols-2 gap-8 animate-in slide-in-from-top-4 fade-in duration-300">
                        
                        {/* Medical History */}
                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                            <span>📋</span> Medical History
                          </h4>
                          <ul className="space-y-2">
                            {patient.history.map((h, i) => (
                              <li key={i} className="flex items-center gap-2 text-slate-700 font-medium before:content-[''] before:w-1.5 before:h-1.5 before:bg-indigo-500 before:rounded-full">{h}</li>
                            ))}
                          </ul>
                        </div>

                        {/* Doctors Involved */}
                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                            <span>👨‍⚕️</span> Care Team
                          </h4>
                          <div className="space-y-3">
                            {patient.doctors.map((doc, i) => (
                              <div key={i} className="flex items-center justify-between">
                                <span className="font-bold text-slate-800">{doc.name}</span>
                                <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-1 rounded-lg font-semibold">{doc.specialty}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Lab Reports */}
                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                            <span>🔬</span> Recent Lab Reports
                          </h4>
                          <div className="space-y-3">
                            {patient.reports.map((report, i) => (
                              <div key={i} className="border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                                <div className="flex justify-between items-center mb-1">
                                  <span className="font-bold text-slate-700">{report.testName}</span>
                                  <span className="text-xs text-slate-400 font-mono">{report.date}</span>
                                </div>
                                <span className={`text-xs font-bold px-2 py-1 rounded-md ${report.result === 'Normal' || report.result === 'Clear' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                  Result: {report.result}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Billing History */}
                        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100">
                          <h4 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center gap-2">
                            <span>💳</span> Billing & Invoices
                          </h4>
                          <div className="space-y-3">
                            {patient.billing.map((bill, i) => (
                              <div key={i} className="flex justify-between items-center border-b border-slate-100 pb-3 last:border-0 last:pb-0">
                                <div>
                                  <span className="font-bold text-slate-700 block">{bill.invoiceId}</span>
                                  <span className="text-xs text-slate-400 font-mono">{bill.date}</span>
                                </div>
                                <div className="text-right">
                                  <span className="font-bold text-slate-800 block">{bill.amount}</span>
                                  <span className={`text-xs font-bold ${bill.status === 'Paid' ? 'text-green-600' : 'text-amber-500'}`}>{bill.status}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Achievements Section */}
      <div className="max-w-7xl mx-auto py-20 px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg transition-shadow">
            <h3 className="text-4xl md:text-5xl font-extrabold text-teal-600 mb-2">100+</h3>
            <p className="text-slate-500 font-medium">Hospitals Integrated</p>
          </div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg transition-shadow">
            <h3 className="text-4xl md:text-5xl font-extrabold text-teal-600 mb-2">400+</h3>
            <p className="text-slate-500 font-medium">Expert Specialists</p>
          </div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg transition-shadow">
            <h3 className="text-4xl md:text-5xl font-extrabold text-teal-600 mb-2">1M+</h3>
            <p className="text-slate-500 font-medium">Patients Managed</p>
          </div>
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-lg transition-shadow">
            <h3 className="text-4xl md:text-5xl font-extrabold text-teal-600 mb-2">24/7</h3>
            <p className="text-slate-500 font-medium">HL7 Data Exchange</p>
          </div>
        </div>
      </div>

      {/* Overview & About Us Section */}
      <div className="bg-teal-900 text-white py-24 px-6 mt-10 relative overflow-hidden">
        {/* Background Accents */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-800 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-emerald-800 rounded-full blur-3xl opacity-50 translate-y-1/2 -translate-x-1/2"></div>

        <div className="max-w-6xl mx-auto flex flex-col md:flex-row gap-16 items-center relative z-10">
          <div className="md:w-1/2">
            <div className="inline-block bg-teal-800 text-teal-200 text-xs font-bold px-4 py-1.5 rounded-full mb-6 uppercase tracking-wider border border-teal-700">About Us & Overview</div>
            <h2 className="text-4xl md:text-5xl font-extrabold mb-6 leading-tight">Revolutionizing Healthcare Interoperability</h2>
            <p className="text-lg text-teal-100 mb-6 leading-relaxed font-light">
              Aspataal is more than just a hospital directory. It is a comprehensive software ecosystem that seamlessly manages complex hospital workflows including patient records, doctors, lab reports, and billing.
            </p>
            <p className="text-lg text-teal-100 mb-8 leading-relaxed font-light">
              By fully utilizing the global <strong>HL7 standard</strong>, we ensure that critical patient data is securely and instantly shared across disparate medical systems, preventing dangerous data silos and ultimately saving lives.
            </p>
            <div className="flex flex-wrap gap-4 text-sm font-semibold text-teal-200">
              <span className="bg-teal-800/60 border border-teal-700 px-5 py-2.5 rounded-xl backdrop-blur-sm">✓ Unified EMR Records</span>
              <span className="bg-teal-800/60 border border-teal-700 px-5 py-2.5 rounded-xl backdrop-blur-sm">✓ Secure HL7 Routing</span>
              <span className="bg-teal-800/60 border border-teal-700 px-5 py-2.5 rounded-xl backdrop-blur-sm">✓ Real-time Interoperability</span>
            </div>
          </div>
          <div className="md:w-1/2 grid grid-cols-2 gap-4">
             <img src="https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=600&auto=format&fit=crop" alt="Doctors collaborating" className="rounded-3xl shadow-2xl w-full h-64 object-cover transform translate-y-8 border-4 border-teal-800/50" />
             <img src="https://images.unsplash.com/photo-1551076805-e1869043e560?q=80&w=600&auto=format&fit=crop" alt="Modern hospital room" className="rounded-3xl shadow-2xl w-full h-64 object-cover border-4 border-teal-800/50" />
          </div>
        </div>
      </div>

      {/* Feedback Section */}
      <div className="bg-white py-24 px-6 border-b-8 border-teal-500">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-800 mb-4">Share Your Feedback</h2>
          <p className="text-lg text-slate-500 mb-10">We are constantly improving the Aspataal platform. Let us know about your experience.</p>
          
          <form className="bg-slate-50 p-8 md:p-10 rounded-3xl shadow-sm border border-slate-100 text-left relative overflow-hidden" onSubmit={handleFeedbackSubmit}>
            
            {feedbackStatus === 'success' && (
              <div className="absolute inset-0 bg-teal-50 z-10 flex flex-col items-center justify-center text-center animate-in fade-in duration-500">
                <div className="w-20 h-20 bg-teal-500 text-white rounded-full flex items-center justify-center text-4xl mb-4 shadow-lg shadow-teal-200">✓</div>
                <h3 className="text-2xl font-bold text-teal-800 mb-2">Thank You!</h3>
                <p className="text-teal-600 font-medium">Your feedback has been securely saved to our database.</p>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Name</label>
                <input type="text" required value={feedbackName} onChange={(e) => setFeedbackName(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white" placeholder="John Doe" />
              </div>
              <div>
                <label className="block text-sm font-bold text-slate-700 mb-2">Email</label>
                <input type="email" required value={feedbackEmail} onChange={(e) => setFeedbackEmail(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white" placeholder="john@example.com" />
              </div>
            </div>
            
            <div className="mb-6">
              <label className="block text-sm font-bold text-slate-700 mb-3">Experience Rating</label>
              <div className="flex gap-4 justify-start">
                {['😡', '😕', '😐', '🙂', '🤩'].map((emoji, i) => (
                  <button 
                    key={i} 
                    type="button" 
                    onClick={() => setFeedbackRating(emoji)}
                    className={`text-4xl hover:scale-125 transition-transform filter hover:drop-shadow-md ${feedbackRating === emoji ? 'scale-125 drop-shadow-lg' : 'opacity-70'}`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-8">
              <label className="block text-sm font-bold text-slate-700 mb-2">Message</label>
              <textarea required value={feedbackMessage} onChange={(e) => setFeedbackMessage(e.target.value)} className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent bg-white h-32 resize-none" placeholder="Tell us what you loved or what we can improve..."></textarea>
            </div>
            
            <button disabled={feedbackStatus === 'submitting'} type="submit" className="w-full bg-teal-600 hover:bg-teal-700 disabled:bg-teal-400 text-white font-bold py-4 rounded-xl transition-colors shadow-lg shadow-teal-200/50 text-lg flex justify-center items-center gap-2">
              {feedbackStatus === 'submitting' ? 'Submitting...' : 'Submit Feedback'}
            </button>
            {feedbackStatus === 'error' && <p className="text-red-500 text-center mt-4 font-bold">Failed to submit feedback. Please try again.</p>}
          </form>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .hide-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
      `}} />
    </main>
  );
}
