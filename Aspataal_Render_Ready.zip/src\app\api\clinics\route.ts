import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET() {
  try {
    const db = await getDb();
    const clinics = await db.all('SELECT * FROM clinics');
    return NextResponse.json(clinics);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch clinics' }, { status: 500 });
  }
}
