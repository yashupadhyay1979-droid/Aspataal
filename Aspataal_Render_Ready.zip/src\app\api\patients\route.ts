import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET() {
  try {
    const db = await getDb();
    const patients = await db.all('SELECT * FROM patients');
    
    // Parse JSON fields
    const parsed = patients.map(p => ({
      ...p,
      history: JSON.parse(p.history),
      reports: JSON.parse(p.reports),
      doctors: JSON.parse(p.doctors),
      billing: JSON.parse(p.billing)
    }));
    
    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch patients' }, { status: 500 });
  }
}
