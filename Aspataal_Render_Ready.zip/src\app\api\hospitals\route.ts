import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function GET() {
  try {
    const db = await getDb();
    const hospitals = await db.all('SELECT * FROM hospitals');
    
    // Parse JSON fields
    const parsed = hospitals.map(h => ({
      ...h,
      specialties: JSON.parse(h.specialties)
    }));
    
    return NextResponse.json(parsed);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch hospitals' }, { status: 500 });
  }
}
