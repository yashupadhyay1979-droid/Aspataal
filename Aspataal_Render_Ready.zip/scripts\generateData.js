const fs = require('fs');
const path = require('path');

// Helper to generate random number
const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const randFloat = (min, max) => (Math.random() * (max - min) + min).toFixed(1);

// Data pools
const firstNamesM = ["Amit", "Rahul", "Vikram", "Suresh", "Rajesh", "Ramesh", "Sanjay", "Arun", "Manoj", "Vijay", "John", "David", "Arif", "Ali", "Kiran"];
const firstNamesF = ["Sneha", "Priya", "Anjali", "Neha", "Kavita", "Deepa", "Pooja", "Sunita", "Anita", "Geeta", "Sarah", "Zara", "Aisha", "Maria"];
const lastNames = ["Sharma", "Patil", "Reddy", "Singh", "Kumar", "Rao", "Iyer", "Gowda", "Nair", "Menon", "Jain", "Agarwal", "Bhat", "Hegde", "Desai", "Khan", "Khan", "Joseph", "Thomas"];
const hospitalPrefixes = ["City", "Global", "Apollo", "Fortis", "Narayana", "Manipal", "Sakra", "Aster", "Sparsh", "Columbia", "St. Johns", "Life", "Care", "Health", "Trust", "Prime", "Elite", "Metro", "Sunrise", "Divine"];
const suffixes = ["Hospital", "Healthcare", "Medical Center", "Super Specialty Hospital", "Institute of Medical Sciences"];
const locations = ["Indiranagar", "Koramangala", "Jayanagar", "Whitefield", "Electronic City", "Hebbal", "Malleswaram", "Basavanagudi", "Banashankari", "BTM Layout", "HSR Layout", "Marathahalli", "Yelahanka", "Rajajinagar", "JP Nagar", "Bellandur", "Kammanahalli", "Ulsoor", "RT Nagar", "Vijayanagar"];
const specialties = ["Cardiology", "Neurology", "Orthopedics", "Oncology", "Pediatrics", "Gastroenterology", "Gynecology", "Urology", "Dermatology", "Ophthalmology"];
const degrees = ["MBBS, MD", "MBBS, MS", "MBBS, DNB", "MBBS, MD, DM", "MBBS, MS, MCh", "MBBS, FRCS"];
const pharmacyNames = ["Apollo Pharmacy", "MedPlus", "Sanjeevini", "HealthCare Pharmacy", "Trust Meds", "LifeLine Chemists", "City Meds", "QuickHeal Pharmacy", "Carewell Chemists", "GoodHealth Pharmacy"];
const clinicNames = ["Care Clinic", "Family Health Center", "Prime Care", "Wellness Clinic", "City Polyclinic", "Health First", "Life Care Clinic", "CureWell", "Heal & Care", "First Choice Clinic"];

// Medical Mock Data
const conditions = ["Hypertension", "Type 2 Diabetes", "Asthma", "Migraine", "Osteoarthritis", "Hyperthyroidism", "None", "None", "None"];
const labTests = ["Complete Blood Count (CBC)", "Lipid Profile", "HbA1c", "Thyroid Panel", "Liver Function Test (LFT)", "Kidney Function Test (KFT)", "Chest X-Ray", "MRI Brain", "ECG"];
const testResults = ["Normal", "Slightly Elevated", "Borderline", "Requires Attention", "Clear"];

// Unsplash Image Arrays (Real photos)
const hospitalImages = [
  "https://images.unsplash.com/photo-1587351021759-3e566b6af7cc?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1538108149393-cebb47ac79cd?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1516549655169-df83a0774514?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1632833239869-a37e3a5806d2?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1586773860418-d37222d8fce3?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1504439468489-c8920d786a2b?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1511174511562-5f7f18bf270f?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1551076805-e1869043e560?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1583324113626-70df0f4deaab?q=80&w=600&auto=format&fit=crop"
];

const pharmacyImages = [
  "https://images.unsplash.com/photo-1587854692152-cbe660dbde88?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1550572017-edb799988a6e?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1631549916768-4119b2e5f926?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1576602976047-174e57a47881?q=80&w=600&auto=format&fit=crop"
];

const clinicImages = [
  "https://images.unsplash.com/photo-1629909613654-28e377c37b09?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1504813184591-01572f98c85f?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1579684385127-1ef15d508118?q=80&w=600&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1584515933487-779824d29309?q=80&w=600&auto=format&fit=crop"
];

const generateMapLink = (name, location) => {
  return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(name + " " + location + " Bangalore");
};

// Generators
const generateHospitals = (count) => {
  const hospitals = [];
  for (let i = 1; i <= count; i++) {
    const primarySpecialty = specialties[rand(0, specialties.length - 1)];
    const otherSpecialties = [primarySpecialty];
    while (otherSpecialties.length < 3) {
      const sp = specialties[rand(0, specialties.length - 1)];
      if (!otherSpecialties.includes(sp)) otherSpecialties.push(sp);
    }

    const name = hospitalPrefixes[rand(0, hospitalPrefixes.length - 1)] + " " + suffixes[rand(0, suffixes.length - 1)] + " " + i;
    const loc = locations[rand(0, locations.length - 1)];

    hospitals.push({
      id: i,
      name: name,
      location: loc,
      specialties: otherSpecialties,
      primarySpecialty: primarySpecialty,
      rating: parseFloat(randFloat(3.5, 5.0)),
      image: hospitalImages[rand(0, hospitalImages.length - 1)],
      contact: "+91 80 " + rand(1000, 9999) + " " + rand(1000, 9999),
      mapLink: generateMapLink(name, loc)
    });
  }
  return hospitals;
};

const generateDoctors = (hospitals, countPerHospital) => {
  const doctors = [];
  let docId = 1;
  hospitals.forEach(hospital => {
    for (let i = 0; i < countPerHospital; i++) {
      const specialty = hospital.specialties[rand(0, hospital.specialties.length - 1)];
      const isMale = Math.random() > 0.5;
      const firstName = isMale ? firstNamesM[rand(0, firstNamesM.length - 1)] : firstNamesF[rand(0, firstNamesF.length - 1)];
      const lastName = lastNames[rand(0, lastNames.length - 1)];
      const imageNum = rand(1, 99);
      const imageUrl = "https://randomuser.me/api/portraits/" + (isMale ? "men" : "women") + "/" + imageNum + ".jpg";

      doctors.push({
        id: docId++,
        name: "Dr. " + firstName + " " + lastName,
        hospitalId: hospital.id,
        hospitalName: hospital.name,
        specialty: specialty,
        qualifications: degrees[rand(0, degrees.length - 1)],
        experience: rand(5, 30) + " years",
        image: imageUrl
      });
    }
  });
  return doctors;
};

const generatePharmacies = (count) => {
  const pharmacies = [];
  for (let i = 1; i <= count; i++) {
    const name = pharmacyNames[rand(0, pharmacyNames.length - 1)];
    const loc = locations[rand(0, locations.length - 1)];
    
    pharmacies.push({
      id: i,
      name: name + " - " + loc,
      location: loc,
      rating: parseFloat(randFloat(3.8, 5.0)),
      isOpen24x7: Math.random() > 0.5,
      contact: "+91 99 " + rand(10000, 99999) + " " + rand(100, 999),
      image: pharmacyImages[rand(0, pharmacyImages.length - 1)],
      mapLink: generateMapLink(name, loc)
    });
  }
  return pharmacies;
};

const generateClinics = (count) => {
  const clinics = [];
  for (let i = 1; i <= count; i++) {
    const specialty = specialties[rand(0, specialties.length - 1)];
    const isMale = Math.random() > 0.5;
    const firstName = isMale ? firstNamesM[rand(0, firstNamesM.length - 1)] : firstNamesF[rand(0, firstNamesF.length - 1)];
    const lastName = lastNames[rand(0, lastNames.length - 1)];
    const doctorName = "Dr. " + firstName + " " + lastName;
    const name = firstName + "'s " + clinicNames[rand(0, clinicNames.length - 1)];
    const loc = locations[rand(0, locations.length - 1)];

    clinics.push({
      id: i,
      name: name,
      doctorName: doctorName,
      specialty: specialty,
      location: loc,
      rating: parseFloat(randFloat(4.0, 5.0)),
      contact: "+91 98 " + rand(10000, 99999) + " " + rand(100, 999),
      image: clinicImages[rand(0, clinicImages.length - 1)],
      mapLink: generateMapLink(name, loc)
    });
  }
  return clinics;
};

const generatePatients = (count, doctorsList) => {
  const patients = [];
  for (let i = 1; i <= count; i++) {
    const isMale = Math.random() > 0.5;
    const firstName = isMale ? firstNamesM[rand(0, firstNamesM.length - 1)] : firstNamesF[rand(0, firstNamesF.length - 1)];
    const lastName = lastNames[rand(0, lastNames.length - 1)];
    
    // Generate Medical History
    const historyCount = rand(1, 3);
    const history = [];
    for(let j=0; j<historyCount; j++) {
      const cond = conditions[rand(0, conditions.length-1)];
      if(!history.includes(cond) && cond !== "None") history.push(cond);
    }
    if(history.length === 0) history.push("No significant past medical history.");

    // Generate Reports
    const reportCount = rand(1, 4);
    const reports = [];
    for(let j=0; j<reportCount; j++) {
      reports.push({
        date: "2023-" + String(rand(1,12)).padStart(2, '0') + "-" + String(rand(1,28)).padStart(2, '0'),
        testName: labTests[rand(0, labTests.length - 1)],
        result: testResults[rand(0, testResults.length - 1)]
      });
    }

    // Assign Doctors
    const docsInvolved = [];
    for(let j=0; j<rand(1,3); j++) {
      const randomDoc = doctorsList[rand(0, doctorsList.length - 1)];
      if(!docsInvolved.find(d => d.id === randomDoc.id)) {
        docsInvolved.push({ id: randomDoc.id, name: randomDoc.name, specialty: randomDoc.specialty });
      }
    }

    // Billing History
    const billCount = rand(1, 3);
    const billing = [];
    for(let j=0; j<billCount; j++) {
      billing.push({
        invoiceId: "INV-" + rand(10000, 99999),
        date: "2023-" + String(rand(1,12)).padStart(2, '0') + "-" + String(rand(1,28)).padStart(2, '0'),
        amount: "₹" + rand(500, 15000),
        status: Math.random() > 0.2 ? "Paid" : "Pending"
      });
    }

    patients.push({
      id: "MRN-" + rand(100000, 999999),
      name: firstName + " " + lastName,
      age: rand(18, 85),
      gender: isMale ? "Male" : "Female",
      bloodGroup: ["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"][rand(0, 7)],
      contact: "+91 9" + rand(10000000, 99999999),
      history: history,
      reports: reports.sort((a,b) => new Date(b.date) - new Date(a.date)),
      doctors: docsInvolved,
      billing: billing.sort((a,b) => new Date(b.date) - new Date(a.date))
    });
  }
  return patients;
};

// Generate Data
const hospitals = generateHospitals(100);
const doctors = generateDoctors(hospitals, 4); // 400 doctors
const pharmacies = generatePharmacies(100);
const clinics = generateClinics(50);
const patients = generatePatients(100, doctors);

const dataDir = path.join(__dirname, '..', 'src', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

fs.writeFileSync(path.join(dataDir, 'hospitals.json'), JSON.stringify(hospitals, null, 2));
fs.writeFileSync(path.join(dataDir, 'doctors.json'), JSON.stringify(doctors, null, 2));
fs.writeFileSync(path.join(dataDir, 'pharmacies.json'), JSON.stringify(pharmacies, null, 2));
fs.writeFileSync(path.join(dataDir, 'clinics.json'), JSON.stringify(clinics, null, 2));
fs.writeFileSync(path.join(dataDir, 'patients.json'), JSON.stringify(patients, null, 2));

console.log("Data generated successfully with Patients Module included!");
