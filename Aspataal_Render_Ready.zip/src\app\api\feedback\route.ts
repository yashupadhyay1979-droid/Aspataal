import { NextResponse } from 'next/server';
import { getDb } from '@/lib/db';

export async function POST(request: Request) {
  try {
    const { name, email, rating, message } = await request.json();

    if (!name || !email || !rating || !message) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    const db = await getDb();
    
    const result = await db.run(
      'INSERT INTO feedback (name, email, rating, message) VALUES (?, ?, ?, ?)',
      [name, email, rating, message]
    );

    return NextResponse.json({ success: true, id: result.lastID }, { status: 201 });
  } catch (error) {
    console.error('Feedback submission error:', error);
    return NextResponse.json({ error: 'Failed to submit feedback' }, { status: 500 });
  }
}
