const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'aspataal.db');

// Read JSON data
const dataDir = path.join(__dirname, '..', 'src', 'data');
const hospitals = JSON.parse(fs.readFileSync(path.join(dataDir, 'hospitals.json'), 'utf8'));
const doctors = JSON.parse(fs.readFileSync(path.join(dataDir, 'doctors.json'), 'utf8'));
const pharmacies = JSON.parse(fs.readFileSync(path.join(dataDir, 'pharmacies.json'), 'utf8'));
const clinics = JSON.parse(fs.readFileSync(path.join(dataDir, 'clinics.json'), 'utf8'));
const patients = JSON.parse(fs.readFileSync(path.join(dataDir, 'patients.json'), 'utf8'));

// Connect to SQLite
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('Could not connect to database', err);
    process.exit(1);
  }
});

db.serialize(() => {
  console.log("Setting up tables...");

  // Hospitals Table
  db.run("CREATE TABLE IF NOT EXISTS hospitals ( id INTEGER PRIMARY KEY, name TEXT, location TEXT, primarySpecialty TEXT, specialties TEXT, rating REAL, image TEXT, contact TEXT, mapLink TEXT )");

  // Doctors Table
  db.run("CREATE TABLE IF NOT EXISTS doctors ( id INTEGER PRIMARY KEY, name TEXT, hospitalId INTEGER, hospitalName TEXT, specialty TEXT, qualifications TEXT, experience TEXT, image TEXT )");

  // Pharmacies Table
  db.run("CREATE TABLE IF NOT EXISTS pharmacies ( id INTEGER PRIMARY KEY, name TEXT, location TEXT, rating REAL, isOpen24x7 INTEGER, contact TEXT, image TEXT, mapLink TEXT )");

  // Clinics Table
  db.run("CREATE TABLE IF NOT EXISTS clinics ( id INTEGER PRIMARY KEY, name TEXT, doctorName TEXT, specialty TEXT, location TEXT, rating REAL, contact TEXT, image TEXT, mapLink TEXT )");

  // Patients Table
  db.run("CREATE TABLE IF NOT EXISTS patients ( id TEXT PRIMARY KEY, name TEXT, age INTEGER, gender TEXT, bloodGroup TEXT, contact TEXT, history TEXT, reports TEXT, doctors TEXT, billing TEXT )");

  // Feedback Table
  db.run("CREATE TABLE IF NOT EXISTS feedback ( id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT, rating TEXT, message TEXT, createdAt DATETIME DEFAULT CURRENT_TIMESTAMP )");

  console.log("Clearing old data...");
  db.run("DELETE FROM hospitals");
  db.run("DELETE FROM doctors");
  db.run("DELETE FROM pharmacies");
  db.run("DELETE FROM clinics");
  db.run("DELETE FROM patients");

  console.log("Inserting massive data records...");

  const insertHospital = db.prepare("INSERT INTO hospitals VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  hospitals.forEach(h => insertHospital.run(h.id, h.name, h.location, h.primarySpecialty, JSON.stringify(h.specialties), h.rating, h.image, h.contact, h.mapLink));
  insertHospital.finalize();

  const insertDoctor = db.prepare("INSERT INTO doctors VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  doctors.forEach(d => insertDoctor.run(d.id, d.name, d.hospitalId, d.hospitalName, d.specialty, d.qualifications, d.experience, d.image));
  insertDoctor.finalize();

  const insertPharmacy = db.prepare("INSERT INTO pharmacies VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  pharmacies.forEach(p => insertPharmacy.run(p.id, p.name, p.location, p.rating, p.isOpen24x7 ? 1 : 0, p.contact, p.image, p.mapLink));
  insertPharmacy.finalize();

  const insertClinic = db.prepare("INSERT INTO clinics VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
  clinics.forEach(c => insertClinic.run(c.id, c.name, c.doctorName, c.specialty, c.location, c.rating, c.contact, c.image, c.mapLink));
  insertClinic.finalize();

  const insertPatient = db.prepare("INSERT INTO patients VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
  patients.forEach(p => insertPatient.run(p.id, p.name, p.age, p.gender, p.bloodGroup, p.contact, JSON.stringify(p.history), JSON.stringify(p.reports), JSON.stringify(p.doctors), JSON.stringify(p.billing)));
  insertPatient.finalize();

  console.log("Seeding complete! SQLite database 'aspataal.db' is ready.");
});

db.close();
